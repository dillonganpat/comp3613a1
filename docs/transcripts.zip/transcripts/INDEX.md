# Session transcripts

Filled by the **Guide agent** (Copilot Agent, Cursor, or OpenCode) when
building the report — one markdown file per Guide chat for this project.
`python manage.py report` only packages these files; it does not scrape an IDE.

Chats packaged: **1**

| Chat | File |
| --- | --- |
| `guide-session` | [guide-session.md](guide-session.md) |
