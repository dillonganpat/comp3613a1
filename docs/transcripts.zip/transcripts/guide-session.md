# Guide Session Transcript

This transcript records the student-guided collaboration across phases 1 through 6 for CampusStay (Student Accommodation).

- **Phase 1:** Selected student accommodation project (CampusStay) with 3 key user workflows: Search/Browse Listings, List a Property, and Book a Listing.
- **Phase 2:** Defined actors (Tenant, Landlord) and use cases, generating the use-case diagram (`docs/diagrams/use-case.png`).
- **Phase 3:** Built the Mermaid ERD (`USER`, `PROPERTY`, `BOOKING`) with properties, foreign keys, and reservation rules.
- **Phase 4:** Mapped wireframe design (`docs/wireframes/Wireframe design.png`) against workflows and established coverage.
- **Phase 5:** Applied clean minimalist theming (`app/static/css/app.css`), implemented thin routes + services + repositories, and polished booking validations (rejecting past check-ins and overlapping dates).
- **Phase 6:** Deployed to Render (`https://faststarter.onrender.com`), verified live workflows, and documented marker logins.
